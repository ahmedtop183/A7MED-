# A7MED SHOP — AI Receipt + Automatic Code Delivery

هذه النسخة تحول طلب فري فاير إلى نظام آلي: الزبون يختار الباقة، يدخل ID، يرفع إشعار التحويل، والخادم يرسل الصورة إلى OpenAI لفحص البيانات الظاهرة ثم، إذا استوفى الإشعار شروط التحقق، يسحب كوداً غير مستخدم من قاعدة البيانات ويسلمه للزبون.

## مهم
- **هذه النسخة لا تعمل كملفات ثابتة على Netlify فقط.** لوحة الإدارة وتسليم الأكواد تحتاج تشغيل `server.js` على استضافة Node.js، مع ضبط متغيرات `.env`. إذا فتحت صفحة الإدارة على Netlify وظهرت لك شاشة كلمة المرور فقط، فهذا لا يعني أن الخادم متصل.
- مفتاح OpenAI لا يوضع في `index.html` ولا في JavaScript الخاص بالزبون. ضعه في متغير `OPENAI_API_KEY` على الخادم.
- فحص الصورة بالذكاء الاصطناعي هو فحص بصري؛ لا يثبت وحده أن العملية البنكية حدثت فعلاً. إذا كان متاحاً لاحقاً API موثوق من بنكك/بوابة الدفع، يجب ربطه قبل التسليم الآلي الكامل.
- النظام الحالي يطابق المبلغ، بيانات المستلم، وجود إشعار واضح، ورقم العملية، ويمنع إعادة استخدام نفس الكود. كما يسجل الطلب في SQLite.

## التشغيل
```bash
npm install
cp .env.example .env
# عدّل OPENAI_API_KEY و ADMIN_PASSWORD
npm start
```
ثم افتح `http://localhost:3000`.

## إضافة الأكواد للإدارة
لوحة الإدارة المخفية: `/a7m3d-control-9x7k.html`
كلمة المرور تؤخذ من `ADMIN_PASSWORD` في `.env`، وليست مكتوبة في الواجهة.

يمكن أيضاً إضافة الأكواد عبر API الإداري بعد تسجيل الدخول، أو تطوير صفحة الإدارة لتستخدم نفس الـAPI.

## النشر
هذه النسخة تحتاج استضافة تشغل Node.js وتوفر تخزيناً دائماً لملف SQLite مثل VPS/Render/Railway مع Disk دائم. لا يكفي نشرها كملفات HTML ثابتة على Netlify وحده، لأن تسليم الأكواد وقاعدة البيانات يحتاجان خادماً.


## PUBG + TikTok AI ordering
- PUBG UC and TikTok coin products use the same AI receipt verification endpoint and separate code-stock pools.
- Add codes for each product from the hidden admin panel.
- For actual digital top-up (rather than code delivery), a game/TikTok fulfillment API is required; this build treats them as code-delivery products.


## نشر جاهز على استضافة واحدة
هذه الحزمة تحتوي على `Dockerfile` و`render.yaml` لتشغيل الموقع والـAPI ولوحة الإدارة وقاعدة البيانات من نفس الرابط، مع قرص دائم لملفات SQLite والإيصالات. راجع `README_DEPLOY.txt`.
