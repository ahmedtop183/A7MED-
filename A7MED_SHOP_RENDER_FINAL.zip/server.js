import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import OpenAI from 'openai';
import Database from 'better-sqlite3';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'CHANGE_ME';
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || '';
// Use DATA_DIR so the database and receipts can live on a persistent disk/volume.
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const uploadDir = path.join(DATA_DIR, 'receipts');
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors({ origin: FRONTEND_ORIGIN || true }));
app.use(express.json({ limit: '1mb' }));
app.get('/health', (_req,res)=>res.json({ok:true,service:'A7MED SHOP'}));

const db = new Database(path.join(DATA_DIR, 'shop.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS products (
  slug TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_slug TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  delivered_at TEXT,
  order_id TEXT,
  FOREIGN KEY(product_slug) REFERENCES products(slug)
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  product_slug TEXT NOT NULL,
  product_name TEXT NOT NULL,
  price INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  receipt_path TEXT NOT NULL,
  ai_result TEXT,
  status TEXT NOT NULL,
  delivered_code TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(product_slug) REFERENCES products(slug)
);
`);

const products = [
  ['ff-100','فري فاير 100💎',8500],
  ['ff-200','فري فاير 200💎',17000],
  ['ff-300','فري فاير 300💎',25500],
  ['ff-500','فري فاير 500💎',45500],
  ['ff-1000','فري فاير 1,000💎',85000],
  ['ff-2000','فري فاير 2,000💎',170000],
  ['pubg-60','ببجي 60 UC',8300],
  ['pubg-120','ببجي 120 UC',16600],
  ['pubg-180','ببجي 180 UC',24900],
  ['pubg-240','ببجي 240 UC',33000],
  ['pubg-325','ببجي 325 UC',41000],
  ['pubg-660','ببجي 660 UC',83000],
  ['pubg-1800','ببجي 1,800 UC',200000],
  ['pubg-3850','ببجي 3,850 UC',380000],
  ['pubg-8100','ببجي 8,100 UC',800000],
  ['tt-140','تيك توك 140🪙',18000],
  ['tt-350','تيك توك 350🪙',37500],
  ['tt-700','تيك توك 700🪙',57000],
  ['tt-1000','تيك توك 1,000🪙',90000],
  ['tt-1500','تيك توك 1,500🪙',125000],
  ['tt-3000','تيك توك 3,000🪙',265000],
  ['tt-6000','تيك توك 6,000🪙',490000],
  ['tt-10000','تيك توك 10,000🪙',795700],
  ['tt-20000','تيك توك 20,000🪙',1606000],
  ['tt-30000','تيك توك 30,000🪙',2387100]
];
const insertProduct = db.prepare('INSERT OR IGNORE INTO products(slug,name,price) VALUES(?,?,?)');
for (const p of products) insertProduct.run(...p);

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`)
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype))
});

function auth(req,res,next){
  const token = req.headers.authorization?.replace(/^Bearer\s+/i,'');
  if (!token || token !== ADMIN_PASSWORD) return res.status(401).json({error:'غير مصرح'});
  next();
}

function dataUrl(file){
  const b64 = fs.readFileSync(file.path).toString('base64');
  return `data:${file.mimetype};base64,${b64}`;
}

async function verifyReceipt(filePath, mime, expectedAmount) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY غير مضبوط في الخادم');
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const imageUrl = `data:${mime};base64,${fs.readFileSync(filePath).toString('base64')}`;
  const prompt = `أنت نظام تحقق لإشعارات تحويل متجر ألعاب سوداني. اقرأ صورة إشعار التحويل فقط ولا تفترض أي معلومة غير ظاهرة.\nالمبلغ المطلوب بالضبط: ${expectedAmount} جنيه سوداني.\nبيانات المتجر المتوقعة: بنكك، رقم الحساب 4187606، الاسم هند محمد.\nأرجع JSON فقط بهذه المفاتيح:\n{\"is_receipt\":boolean,\"payment_status\":\"paid\"|\"not_paid\"|\"unclear\",\"amount\":number|null,\"transaction_id\":string|null,\"sender\":string|null,\"receiver\":string|null,\"account\":string|null,\"bank\":string|null,\"amount_matches\":boolean,\"receiver_matches\":boolean,\"confidence\":number,\"reason\":string}\nإذا كان النص غير واضح أو الصورة ليست إشعار تحويل حقيقياً واضحاً، استخدم unclear و is_receipt=false أو confidence منخفضة. لا تعتبر كلمة أو رقم مكتوب من المستخدم دليلاً على الدفع.`;
  const response = await client.responses.create({
    model: MODEL,
    input: [{ role:'user', content:[{type:'input_text',text:prompt},{type:'input_image',image_url:imageUrl,detail:'high'}] }]
  });
  let raw = response.output_text?.trim() || '';
  raw = raw.replace(/^```json\s*/i,'').replace(/```$/,'').trim();
  return JSON.parse(raw);
}

app.get('/api/products', (_req,res)=>{
  const rows = db.prepare('SELECT slug,name,price,COUNT(c.id) stock FROM products p LEFT JOIN codes c ON c.product_slug=p.slug AND c.delivered_at IS NULL WHERE p.active=1 GROUP BY p.slug').all();
  res.json(rows);
});

app.post('/api/orders', upload.single('receipt'), async (req,res)=>{
  let receiptFile = req.file;
  try {
    if (!receiptFile) return res.status(400).json({error:'أرسل صورة إشعار التحويل'});
    const { productSlug, playerId } = req.body;
    if (!productSlug || !playerId) return res.status(400).json({error:'أدخل المنتج وID اللعبة'});
    const product = db.prepare('SELECT * FROM products WHERE slug=? AND active=1').get(productSlug);
    if (!product) return res.status(404).json({error:'المنتج غير موجود'});
    const orderId = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    db.prepare('INSERT INTO orders(id,product_slug,product_name,price,player_id,receipt_path,status,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .run(orderId,product.slug,product.name,product.price,playerId,receiptFile.path,'checking',createdAt);

    let ai;
    try { ai = await verifyReceipt(receiptFile, receiptFile.mimetype, product.price); }
    catch (e) {
      db.prepare('UPDATE orders SET status=?,ai_result=? WHERE id=?').run('ai_error', JSON.stringify({error:e.message}), orderId);
      return res.status(502).json({error:'تعذر فحص الإشعار حالياً. حاول مرة أخرى.',orderId});
    }
    db.prepare('UPDATE orders SET ai_result=? WHERE id=?').run(JSON.stringify(ai), orderId);

    const valid = ai?.is_receipt === true && ai?.payment_status === 'paid' && ai?.amount_matches === true && ai?.receiver_matches === true && Number(ai?.confidence || 0) >= 0.90;
    if (!valid) {
      db.prepare('UPDATE orders SET status=? WHERE id=?').run('rejected', orderId);
      return res.status(422).json({error:'لم يتم اعتماد إشعار التحويل تلقائياً.',orderId,reason:ai?.reason || 'بيانات الإشعار غير كافية أو غير مطابقة.'});
    }

    const deliver = db.transaction(() => {
      const code = db.prepare('SELECT id,code FROM codes WHERE product_slug=? AND delivered_at IS NULL ORDER BY id LIMIT 1').get(product.slug);
      if (!code) return null;
      const now = new Date().toISOString();
      db.prepare('UPDATE codes SET delivered_at=?,order_id=? WHERE id=? AND delivered_at IS NULL').run(now,orderId,code.id);
      db.prepare('UPDATE orders SET status=?,delivered_code=? WHERE id=?').run('delivered',code.code,orderId);
      return code.code;
    });
    const code = deliver();
    if (!code) {
      db.prepare('UPDATE orders SET status=? WHERE id=?').run('awaiting_stock',orderId);
      return res.status(409).json({error:'تم قبول التحويل لكن الكود غير متوفر حالياً. راجع الإدارة.',orderId});
    }
    res.json({ok:true,orderId,product:product.name,playerId,code,message:'تم التحقق وتسليم الكود.'});
  } finally {
    // Keep receipts for audit; admin can delete them later.
  }
});

app.get('/api/admin/orders', auth, (_req,res)=>{
  const rows=db.prepare('SELECT id,product_name,price,player_id,status,delivered_code,created_at,ai_result FROM orders ORDER BY created_at DESC LIMIT 100').all();
  res.json(rows);
});
app.get('/api/admin/stock', auth, (_req,res)=>{
  const rows=db.prepare('SELECT p.slug,p.name,p.price,COUNT(c.id) stock FROM products p LEFT JOIN codes c ON c.product_slug=p.slug AND c.delivered_at IS NULL GROUP BY p.slug').all();
  res.json(rows);
});
app.post('/api/admin/stock', auth, (req,res)=>{
  const {productSlug,codes}=req.body;
  if(!productSlug || !Array.isArray(codes)) return res.status(400).json({error:'بيانات غير صحيحة'});
  const product=db.prepare('SELECT slug FROM products WHERE slug=?').get(productSlug);
  if(!product) return res.status(404).json({error:'المنتج غير موجود'});
  const stmt=db.prepare('INSERT OR IGNORE INTO codes(product_slug,code) VALUES(?,?)');
  const add=db.transaction(items=>{let n=0;for(const c of items){const code=String(c||'').trim();if(code){const r=stmt.run(productSlug,code);if(r.changes)n++;}}return n;});
  res.json({added:add(codes)});
});

const publicDir = __dirname;
app.use(express.static(publicDir));
app.get('*', (_req,res)=>res.sendFile(path.join(publicDir,'index.html')));
app.listen(PORT,()=>console.log(`A7MED AI server running on port ${PORT}`));
