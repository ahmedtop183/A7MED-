A7MED SHOP — تشغيل الإدارة والطلبات على استضافة واحدة

النسخة دي مجهزة لتشغيل الموقع + API + لوحة الإدارة + SQLite + صور الإيصالات من نفس الرابط.

الخيار المجهز: Render
1) ارفع مجلد المشروع إلى GitHub.
2) في Render اختر New > Blueprint ثم اختر المستودع.
3) Render سيقرأ render.yaml.
4) أدخل OPENAI_API_KEY و ADMIN_PASSWORD عند طلب القيم السرية.
5) بعد النشر افتح رابط الموقع نفسه.
6) الإدارة تكون من:
   /a7m3d-control-9x7k.html

مهم:
- لا تنشر index.html منفصلاً على Netlify؛ هذا المشروع يحتاج Node.js.
- قاعدة البيانات وصور الإيصالات محفوظة في /app/data على القرص الدائم.
- إذا غيرت ADMIN_PASSWORD من إعدادات الاستضافة، استخدم الكلمة الجديدة في صفحة الإدارة.
- endpoint /health يستخدم للتأكد أن الخادم يعمل.

تشغيل محلي:
npm install
cp .env.example .env
npm start
ثم افتح http://localhost:3000
